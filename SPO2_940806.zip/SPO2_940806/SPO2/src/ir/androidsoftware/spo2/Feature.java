package ir.androidsoftware.spo2;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;

import android.os.Environment;

public class Feature {
	// features 
	String MinSpO2="" ;
	String MeanSpO2="" ;
	String stdSpO2="" ;
	String crrSpO2="" ;

	String muinfSpO2="" ;
	
	String zcSpO2="" ;
	String DeltaindSpO2="" ;
	String CTMSpO2="" ;

	String baselineSpO2="" ;
	String odiSpO2="" ;
	String ODISpO2="" ;
	
	String ODISSpO2="" ;
	
	String tsaSpO2="" ;
	
	String labelSpO2="" ;
	// end features
	int[] ODIS ;
	String FileName;
	
	public  Feature(String FileName)
	{
		this.FileName = FileName;
		File myFile = new File(Environment.getExternalStorageDirectory()+"/ApneaPack/" + File.separator +FileName);
		if (myFile.exists()) {
			myFile.delete();
		}
		
		ODIS = new int[6] ;
		LogToFile(BuildArff(),FileName) ;
	}
	private void Clear(){
		 MinSpO2="" ;
		 MeanSpO2="" ;
		 stdSpO2="" ;
		 crrSpO2="" ;

		 muinfSpO2="" ;
		
		 zcSpO2="" ;
		 DeltaindSpO2="" ;
		 CTMSpO2="" ;

		 baselineSpO2="" ;
		 odiSpO2="" ;
		 ODISpO2="" ;
		
		 ODISSpO2="" ;
		
		 tsaSpO2="" ;
		
		 labelSpO2="" ;
	}
	
	public void GetFeatures(double[] spo2) // input (6000)
	{
		Clear();
		 Min(spo2) ;
		 Mean(spo2) ;
		
		double StdSpo2 =  StandardDeviation(spo2);

	
		double[] corrmtx = corrmtx(spo2) ;

		// mutin 
		
		double[][] Ex =  Extra(spo2);
		double[] first = new double[55];
		double[] second = new double[55];
		for (int k = 0; k < 5; k++) {
			for (int i = 0; i < 55 ; i++) {
				first[i] = Ex[i][k] ;
				second[i] = Ex[i][k+1] ;
			}
			mutin(first , second);
		}
		
		
		 ZeroCrossing(spo2);
		daltaIndex(spo2);
		double[] ress = CTM(spo2) ;

		 baseline(spo2);
		double [] od = ODI(spo2) ;
		
		for (int i = 2; i < 6 ; i++) {  // maybe ODI.length != 6
			od = ODI(spo2 ,  i) ;
			for (double d : od) {
				ODISpO2 = ODISpO2 +( String.valueOf(Math.round(d)).equals(null) ? "?" : String.valueOf(Math.round(d))) +",";
			}
		}
		for (int i = 2; i < ODIS.length; i++) {
			ODISSpO2 = ODISSpO2 +( String.valueOf(Math.round(ODIS[i])).equals(null) ? "?" : String.valueOf(Math.round(ODIS[i]))) +",";
		}
		
		int tsas[]=new int[6] ;
		for (int i =0 , j = 70 ; i < 6 ; i++ , j+=5) {
			tsas[i] = TSA(spo2 , j);
		}
		String Features =  MinSpO2 + MeanSpO2 +stdSpO2 + crrSpO2 +muinfSpO2 + zcSpO2 + DeltaindSpO2 
						+ CTMSpO2 + baselineSpO2 + odiSpO2  + ODISpO2 + ODISSpO2 + tsaSpO2 +(tsas[5]>=10 ? "+":  "-") ;
		
		LogToFile(Features,  FileName);
	}
	
	private double[][] Extra(double[] input)
	{			
		double[][] X = new double[55][6] ;
		
		for (int i = 0; i < 55 ; i++) {
			for (int j = 0; j < 6 ; j++) {
				X[i][j] = input[5+i-j] ;
			}
		}
		return X ; 
	}
	
	private double[] corrmtx(double[] input ) 
	{
		double[][] X = new double[55][6] ;
		double[][] Y = new double[6][55] ;

		X = Extra(input) ;
		
		for (int i = 0; i < 55 ; i++) {
			for (int j = 0; j < 6 ; j++) {
				Y[j][i] = X[i][j];
			}
		}
		
		double[][] R = new double[6][6]; // ماتریس باید متقارن باشد
		double maxR = 0 ; 
		for (int i = 0; i < 6 ; i++) {
			for (int j = 0; j < 6 ; j++) {
				double res = 0 ;
				for (int k = 0; k < 55 ; k++) {
					res += X[k][i]*Y[j][k];
				}
				R[i][j] = res ;
				if(res > maxR )
					maxR = res ; 
			}
		}
		
		for (int i = 0; i < 6 ; i++) {
			for (int j = 0; j < 6 ; j++) {
				R[i][j] =  R[i][j] / maxR ;
			}
		}
		
		
		double []CrrSpo2 = new double[6] ;		
		double max = 0 ;
		for (int i = 0; i < R.length; i++) {
			max  =( max > R[i][0] ? max : R[i][0]) ;
		}
		for (int i = 0; i < R.length; i++) {
			CrrSpo2[i] = R[i][0] / max ;  
			if (i!=0)
				crrSpO2 = crrSpO2 +(String.valueOf(Math.round(CrrSpo2[i])).equals(null) ? "?" : String.valueOf(Math.round(CrrSpo2[i])))+"," ; 
		}
		
		return CrrSpo2;
		
	}

	private double StandardDeviation(double[] in) // انحراف معیار
	{
		double min = Mean(in) ;
		double sum = 0 ;
		for (int i=0 ; i< in.length ; i ++ ) {
			sum+=  Math.pow(in[i] - min  , 2 ) ; 
		}
		sum = sum / (in.length -1) ; 
		stdSpO2 = (String.valueOf(Math.round( Math.sqrt(sum))).equals(null) ? "?" : String.valueOf(Math.round(Math.sqrt(sum))))+",";
		return Math.sqrt(sum);
	}
	
	private double Min(double[] in)
	{
		double min=1000;	
		for (double i : in) {
			min = (min > i ? i : min ) ; 
		}
		
		MinSpO2 =(String.valueOf(Math.round(min)).equals(null) ? "?" : String.valueOf(Math.round(min)))+",";
		return min;
	}
	
	private double Max(double[] in)
	{
		double max=0;	
		for (double i : in) {
			max = (max < i ? i : max ) ; 
		}
		return max;
	}
	
	private double Mean(double[] spo2)
	{
		double sum=0;
		for (double i : spo2) {
			sum += i ; 
		}
		sum = sum / spo2.length ;
		MeanSpO2 = (String.valueOf(Math.round(sum)).equals(null) ? "?" : String.valueOf(Math.round(sum)))+",";
		return sum;
	}
	
	private double mutin(double[] first , double[] second)
	{
		int N = first.length;
		
		double[] Fsorted = new double[first.length];
		double[] Ssorted = new double[second.length];
		for (int i = 0; i < first.length; i++) 
			Fsorted[i]=first[i];
		 Fsorted = BubbleSort(Fsorted);
		
		for (int i = 0; i < second.length; i++) 
			Ssorted[i] = second[i];
		 Ssorted = BubbleSort(Ssorted);
		
		int[][] ydatTemp = new int[2][N]; 		
		ydatTemp[0] = indexer(first, Fsorted) ;
		ydatTemp[1] = indexer(second, Ssorted) ;
		
		int[][] ydat = new int[3][N+1]; 
		ydat[0][0]= 0; ydat[1][0]= 0 ;
		for (int i = 1; i <= 2; i++) {
			for (int j = 1; j <= N; j++) {
				ydat[i][j] = ydatTemp[i-1][j-1]+1;
			}
		}
		
		int npar=1;
		double  xcor=0 ;
		int[] poc = new int[10];
		int[] kon = new int[10];
		for (int i = 1; i < poc.length; i++) {
			poc[i]=0;
			kon[i]=0;
		}
		poc[1]=1;
		kon[1]=N;
		int[] poradi = new int[N+1];
		for (int i = 1; i <= N; i++) {
			poradi[i]=i;
		}
		double[][] NN = new double[2][5];
		
		
		double[][] marg = new double[21][5];
		/*for (int i = 1; i <= 20 ; i++) {
			for (int j = 1; j <= 4 ; j++) {
				marg[i][j]=0;
			}
		}*/
		marg[1][1] = 1 ; marg[1][2] = 1 ;
		marg[1][3] = N ; marg[1][4] = N ;
		int run =0 ; 
		while (npar > 0 ) {
			run ++ ;
			int apoc = poc[npar]; 
			int akon = kon[npar];
			int[][] apor = new int[2][akon - apoc  + 2] ;
			for (int i = apoc, j=1; i <= akon; i++ , j++) {
				apor[1][j] = poradi[i] ; 
			} 
			
			 int Nex = apor[1].length -1;
			 double avg = (marg[npar][1] +  marg[npar][3])/(double)2 ;  
			 double avg1 = (marg[npar][2] +  marg[npar][4])/(double)2 ;  
			 int[][] ave = new int[2][3] ;
			 ave[1][1] = (int) avg ;
			 ave[1][1] = (avg < 0 ? ave[1][1]-1:ave[1][1]);
			 ave[1][2] = (int) avg1 ;
			 ave[1][2] = (avg < 0 ? ave[1][2]-1:ave[1][2]);
			 
			 Boolean[][] J = new Boolean[3][akon - apoc  + 2]; 
			 for (int i = 1; i < akon - apoc + 2; i++) {
				J[1][i] = (ydat[1][apor[1][i]]<= ave[1][1] ? true : false) ;
				J[2][i] = (ydat[2][apor[1][i]] <= ave[1][2] ? true : false) ;
			 }
			 
			 Boolean[][] I = new Boolean[akon - apoc + 2][5];
			 
			 for (int i = 1; i < I.length; i++) {
				I[i][1] = J[1][i] && J[2][i] ;
				I[i][2] = J[1][i] && !J[2][i] ;
				I[i][3] = !J[1][i] && J[2][i] ;
				I[i][4] = !J[1][i] && !J[2][i] ;
			 }
			 double[][] amarg = new double[5][5]; 
			 amarg[1][1] = marg[npar][1] ;	amarg[1][2] = marg[npar][2] ;	amarg[1][3] = ave[1][1];		amarg[1][4] = ave[1][2];
			 amarg[2][1] = marg[npar][1] ;	amarg[2][2] = ave[1][2]+1 ;		amarg[2][3] = ave[1][1];		amarg[2][4] = marg[npar][4];
			 amarg[3][1] = ave[1][1]+1 ;	amarg[3][2] = marg[npar][2] ;	amarg[3][3] = marg[npar][3];	amarg[3][4] = ave[1][2];
			 amarg[4][1] = ave[1][1]+1 ;	amarg[4][2] = ave[1][2]+1  ;	amarg[4][3] = marg[npar][3];	amarg[4][4] = marg[npar][4];
			 
			 for (int k = 1; k <= 4 ; k++) {
				int sum=0;
				for (int j = 1; j < I.length ; j++) {
					 sum += (I[j][k]==true ? 1 : 0 ) ; 
				} 
				NN[1][k] = sum ;
			 }
			 double sum=0;
			 for (int k = 1; k < NN[1].length; k++) {
				 double tmp = NN[1][k]-(double)Nex/(double)4;
				 sum += Math.pow(tmp, 2)  ; 
			}
			double tst =(double)4 *sum / (double)Nex ;
			if (tst > 7.8 || run == 1) {
				npar -- ;
				for (int ind = 1; ind <= 4 ; ind++) {	
					if (NN[1][ind] > 2 ) {
						npar ++;
						akon = (int) (apoc + NN[1][ind]-1) ; 
						poc[npar] = apoc;
						kon[npar] = akon ;
						for (int k = 1; k < amarg.length; k++) {
							marg[npar][k] = amarg[ind][k];
						}
						//find begin
						int s = 0;
						for (int k = 1; k < I.length; k++) {
							if( I[k][ind]==true ) s++;
						}
						int[] aindex = new int[s+1] ;
						int l =0;
						for (int k = 1; k < I.length; k++) {
							if( I[k][ind]==true ) 
								aindex[++l] = k ;
						}
						for (int k = apoc , m=1; k <= akon && m < aindex.length ; k++ , m++) {
							poradi[k] = apor[1][aindex[m]] ;
						}
						//find end
						apoc=akon+1; 
					}
					else
					{
						if (NN[1][ind] > 0){
							double Nx=amarg[ind][3]-amarg[ind][1]+1; 
		                    double Ny=amarg[ind][4]-amarg[ind][2]+1; 
		                    xcor=xcor+(double)NN[1][ind]*Math.log((double)(NN[1][ind]/(double)(Nx*Ny)));
						}
					}
				}
				
			}
			else
			{
				 double Nx=marg[npar][3]-marg[npar][1]+1; 
			     double Ny=marg[npar][4]-marg[npar][2]+1; 
			     xcor=xcor+Nex*Math.log((double)(Nex/(double)(Nx*Ny))); 
			     npar=npar-1; 
			}
		}
		
		xcor =(double)xcor/N + Math.log(N);
		muinfSpO2 =muinfSpO2+(String.valueOf(Math.round(xcor)).equals(null) ? "?" : String.valueOf(Math.round(xcor)))+",";
		return xcor;
	}
	
	private int[] indexer(double[] Frow,double[] Fsorted){
		int[] index = new int[Frow.length];
		for (int i = 0; i < Frow.length; i++) {
			for (int j = 0; j < Fsorted.length; j++) {
				if(Frow[i]==Fsorted[j])
				{
					index[i] = j ;
					Fsorted[j]=-1; 
					break;
				}
			}
		}
		return index ;
	}
	private int ZeroCrossing (double[] in)
	{
		int counter = 0 ; 
		double Mean = Mean(in);
		int[] Cross = new int[in.length] ;
		for (int i = 0; i < in.length; i++) {
			if(in[i]-Mean > 0 )
				Cross[i] = 1 ;
			else if(in[i]-Mean < 0 )
				Cross[i]=-1;
			else 
				Cross[i]=0;
		}
		for (int i = 0; i < Cross.length-1; i++) {
			if(Cross[i] - Cross[i+1] == 2 || Cross[i] - Cross[i+1] == -2 )
				counter ++ ;
		}
		if(Cross[Cross.length-2] - Cross[Cross.length-1] == 2 || Cross[Cross.length-2] - Cross[Cross.length-1] == -2 )
			counter ++ ;
		zcSpO2 =(String.valueOf(Math.round(counter)).equals(null) ? "?" : String.valueOf(Math.round(counter)))+",";
		return counter ;
	}
	
	private double daltaIndex(double[] in)
	{
		double[] Mean = new double[in.length / 12];
		double sum=0;
		for (int i = 0,k=0; i < in.length; i+= 12,k++) {
			sum=0;
			for(int j=i ; (j-i) < 12 ; j++){
				
				sum += in[j];
			}
			Mean[k] = sum/12 ;
		}
		double res = (abs( Mean[0]-Mean[1])+abs( Mean[1]-Mean[2] )+ abs(Mean[2]-Mean[3]) +abs( Mean[3]-Mean[4]) )/4 ;
		DeltaindSpO2 =( String.valueOf(Math.round(res)).equals(null) ? "?" : String.valueOf(Math.round(res)))+",";
		return res; 
	}
	
	private double abs(double singed)
	{
		return (singed>0 ? singed : -1*singed) ;
	}
	
	private int[] Sort( double[] in)	
	{
		int[] index = new int[in.length];
		for (int i = 0; i < index.length; i++) {
			index[i]=i;
		}
		for (int i = 0; i < in.length ; i++) {
			double max = in[i];
			int tindex = i ;
			for (int j = i; j < in.length ; j++) {
				if(max < in[j]  ){
					max = in[j];
					tindex =j;				
				}
			}
			index[i]=tindex;
		}
		return index;
	}
	
	private double[] BubbleSort( double[] in)	
	{
		int[] index = new int[in.length];
		for (int i = 0; i < index.length; i++) {
			index[i]=i;
		}
		for (int i = 0; i < in.length; i++) {
			for (int j = 0; j < in.length-1; j++) {
				if(in[j+1]<in[j])
				{
					double tmp = in[j+1];
					in[j+1] = in[j];
					in[j]=tmp;
					int intex = index[j];
					index[j] = index[j+1];
					index[j+1]=intex;
				}
			}
		}
		return in;
	}

	
	private double[] CTM(double[] input)
	{
		double[][] X = new double[55][6] ;
		X = Extra(input) ;
		int[][] delta = new int[X.length][4] ;
		// double[] SSS = new double[X.length]; /// 4debug 
		double[] ctm = new double[4] ;
		// X.length should be 55
		for (int i = 0; i < X.length; i++) {
			double S = Math.sqrt(Math.pow(X[i][2]-X[i][1], 2) + Math.pow(X[i][1]-X[i][0], 2) );
			// SSS[i] = S ; 4debug 
			delta[i][0] = (S < 0.25 ? 1 : 0 ) ;
			delta[i][1] = (S < 0.5 ? 1 : 0 ) ;
			delta[i][2] = (S < 0.75 ? 1 : 0 ) ;
			delta[i][3] = (S < 1 ? 1 : 0 ) ;
		}
		double[] sum= new double[4] ;
		for (int i = 0; i < X.length; i++) {
			sum[0] += delta[i][0] ;
			sum[1] += delta[i][1] ;
			sum[2] += delta[i][2] ;
			sum[3] += delta[i][3] ;
		}
		for (int i = 0; i < sum.length; i++) {
			ctm[i] = sum[i] / X.length ;
			CTMSpO2 = CTMSpO2 +(String.valueOf(Math.round(ctm[i])).equals(null) ? "?" : String.valueOf(Math.round(ctm[i])))+",";
		}
		
		return ctm ;
	}
	
	private double baseline(double[] input)
	{
		double min = Min(input) ;
		double max = Max(input);
		double base = max - (max - min) * 0.2 ;
		double sum = 0 ; 
		int count = 0 ;
		for (int i = 0; i < input.length; i++) {
			if (input[i] >= base) {
				sum += input[i] ;
				count ++ ; 
			}
		}
		baselineSpO2 = (String.valueOf(Math.round(sum/count)).equals(null) ? "?" : String.valueOf(Math.round(sum/count)))+",";
		return sum/count ; 
	}
	
	private double[] ODI(double[] input)

	{
		double[] odi = new double[3];
		odi[0] = 0 ; odi[1] = 0 ; odi[2] = 0 ;
		double bs = Double.valueOf(baselineSpO2.split(",")[0] ) ;
		for (int i = 0; i < input.length; i++) {
			if (input[i]<= (0.98 * bs) && input[i] > (0.97 * bs) ) 
				odi[0] ++ ;
			if  (input[i]<= (0.97 * bs) && input[i] > (0.96 * bs) )
				odi[1]++;
			if  (input[i]<= (0.96 * bs)  ) 
				odi[2]++;
		}
		for (int i = 0; i < odi.length; i++) {
			odi[i] = odi[i] / input.length ;
			odiSpO2 =odiSpO2 +( String.valueOf(Math.round(odi[i])).equals(null) ? "?" :  String.valueOf(Math.round(odi[i])))+"," ;
		}
		return odi ;
	}
	
	private double[] ODI(double[] input , int k )
	{
		double[] odi = new double[3];
		double bs = baseline(input)* (1 - 0.01 * k ) ;
		odi[0] = 0 ; odi[1] = 0 ; odi[2] = 0 ;
		double[] index = new double[60] ; 
		for (int i = 0; i < input.length; i++) {
			if(input[i] <= bs ){
				index[i]=1 ;
				ODIS[k] ++;
			}
			else
				index[i]=0;
		}
		
		for (int i = 1; i < input.length; i++) {
			if (index[i]==1 && index[i-1]==1) {
				odi[0] ++ ; 
			}
		}
		for (int i = 3; i < input.length; i++) {
			if (index[i]==1 && index[i-1]==1 && index[i-2]==1 && index[i-3]==1) {
				odi[1] ++ ; 
			}
		}
		for (int i = 5; i < input.length; i++) {
			if (index[i]==1 && index[i-1]==1 && index[i-2]==1 && index[i-3]==1 && index[i-4]==1 && index[i-5]==1) {
				odi[2] ++ ; 
			}
		}

		return odi ;
	}
	
	private int TSA(double[] input , int k )
	{
		int tsa=0;

		for (int i = 1; i < input.length; i++) {
			if(input[i] < k && input[i-1] < k  )
				tsa ++;
		}
		if (k!=75)
			tsaSpO2 =tsaSpO2+(String.valueOf(Math.round(tsa)).equals(null) ? "?" : String.valueOf(Math.round(tsa)))+",";
		return tsa ;
	}
	
	
	public  void LogToFile(String data , String FileName)
	{
			
		
		StringWriter sw = new StringWriter();
	    PrintWriter pw = new PrintWriter(sw);
	    //ex.printStackTrace(pw);
	    
	    data += sw.toString();
		try {
			File mydir = new File(Environment.getExternalStorageDirectory()+"/ApneaPack" );
			if(mydir.exists()==false)
			{
				mydir.mkdir();
			}
			File myFile = new File(Environment.getExternalStorageDirectory()+"/ApneaPack/" + File.separator +FileName);
			
			if(myFile.exists()==false)
			{
				try {
					myFile.createNewFile();
				} catch (IOException e1) {
					e1.printStackTrace();
				}
			}
			try {
				BufferedWriter buf = new BufferedWriter(new FileWriter(myFile,true));
				buf.append(data);
			    buf.newLine();
			    buf.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
					
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	private String BuildArff() 
	{
		String arff = "@relation data \n \n"
+"@attribute MinSpO2 numeric\n" 
+"@attribute MeanSpO2 numeric\n" 
+"@attribute stdSpO2 numeric\n"
+"@attribute crr1SpO2 numeric\n"
+"@attribute crr2SpO2 numeric\n"
+"@attribute crr3SpO2 numeric\n"
+"@attribute crr4SpO2 numeric\n"
+"@attribute crr5SpO2 numeric\n"
+"@attribute muinf1SpO2 numeric\n"
+"@attribute muinf2SpO2 numeric\n"
+"@attribute muinf3SpO2 numeric\n"
+"@attribute muinf4SpO2 numeric\n"
+"@attribute muinf5SpO2 numeric\n"
+"@attribute zcSpO2 numeric\n"
+"@attribute Deltaind numeric\n"
+"@attribute CTM25 numeric\n"
+"@attribute CTM50 numeric\n"
+"@attribute CTM75 numeric\n"
+"@attribute CTM100 numeric\n"
+"@attribute baseline numeric\n"
+"@attribute odi2 numeric\n"
+"@attribute odi3 numeric\n"
+"@attribute odi4 numeric\n"
+"@attribute ODI21 numeric\n"
+"@attribute ODI23 numeric\n"
+"@attribute ODI25 numeric\n"
+"@attribute ODI31 numeric\n"
+"@attribute ODI33 numeric\n"
+"@attribute ODI35 numeric\n"
+"@attribute ODI41 numeric\n"
+"@attribute ODI43 numeric\n"
+"@attribute ODI45 numeric\n"
+"@attribute ODI51 numeric\n"
+"@attribute ODI53 numeric\n"
+"@attribute ODI55 numeric\n"
+"@attribute ODIS2 numeric\n"
+"@attribute ODIS3 numeric\n"
+"@attribute ODIS4 numeric\n"
+"@attribute ODIS5 numeric\n"
+"@attribute tsa70 numeric\n"
+"@attribute tsa80 numeric\n"
+"@attribute tsa85 numeric\n"
+"@attribute tsa90 numeric\n"
+"@attribute tsa95 numeric\n"
+"@attribute label {-,+}\n\n"
+"@data\n";
		
		return arff ;
	}

}
