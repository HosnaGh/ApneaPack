package ir.androidsoftware.spo2;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Set;
import java.util.UUID;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothServerSocket;
import android.bluetooth.BluetoothSocket;
import android.util.Log;

public class BluetoothReader {

	private final UUID BtDeviceUUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
	//private final UUID BtDeviceUUID2 = UUID.fromString("fa87c0d0-afac-11de-8a39-0800200c9a66");
	private final String BtDeviceName = "Nonin_Medical_Inc._927521";
	private final String DEBUG_TAG = "BT";
	
	private BluetoothAdapter btAdapter;
	private BluetoothSocket btSocket;
	private InputStream in;
	private OutputStream out;	
	private boolean started = false; ;
	
	public BluetoothReader()
	{
		btAdapter = BluetoothAdapter.getDefaultAdapter();		
	}
	
	public boolean isBtEnabled()
	{
		return btAdapter.isEnabled();
	}
	
	public boolean isStarted()
	{
		return started;
	}
	
	public void connect() throws IOException
	{
		Set<BluetoothDevice> pairedDevices = btAdapter.getBondedDevices();		
		for (BluetoothDevice btDevice : pairedDevices) {
			BluetoothServerSocket tmpSocket;
			if( btDevice.getName().equals(BtDeviceName))
			{					
					btSocket = btDevice.createRfcommSocketToServiceRecord(BtDeviceUUID);
					//if(btSocket==null)
						//btSocket = btDevice.createRfcommSocketToServiceRecord(BtDeviceUUID2);
					btSocket.connect();
					in = btSocket.getInputStream();
					out = btSocket.getOutputStream();									
			}
		}
	}
	public void disconnect()
	{
		if(btSocket != null)
		{
			try {
				btSocket.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	void sendCMD(byte[] data) throws IOException
	{		
		out.write(data);
		out.flush();
	}	
	
	byte[] receiveReply() throws IOException
	{
		int bufferSize = 32;
		int readSize = 0;
		byte[] buffer = new byte[bufferSize];
		
		while ( (readSize = in.read(buffer))!=-1) {
			if(readSize>0)
			{
				byte[] bufferOut = new byte[readSize];
				String hex="";
				for (int i=0;i<readSize;i++) {
					bufferOut[i] = buffer[i];
					hex+=Integer.toHexString(bufferOut[i])+" ";
				}
				Log.d(DEBUG_TAG, hex);	
				return bufferOut;
			}			
		};

		return buffer;
	}
	
	
	
	public void startBtOp(final MainActivity mainActivity) 
	{
		started = true;
		Runnable runn =new Runnable() {			
			@Override
			public void run() {
				try {			
					byte[] cmdSetFormat = new byte[]{0x02, 0x70, 0x04, 0x02, 0x08, 0x00, 0x7E, 0x03};
					sendCMD(cmdSetFormat);
					Thread.sleep(500);
					do{												
						byte[] reply = receiveReply();
						if(reply.length==4)
						{
							byte pulse = reply[1];
							byte spO2 = reply[2];
							mainActivity.displayVals(spO2, pulse);
						}
					}while(started);								
				} catch (Exception e) {					
					e.printStackTrace();
				} 
			}
		};				
		new Thread(runn).start();
	}	
	
	public void stopBt(){
		started = false;
	}
}
