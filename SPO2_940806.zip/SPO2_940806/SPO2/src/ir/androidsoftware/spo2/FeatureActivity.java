package ir.androidsoftware.spo2;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.List;

import android.media.audiofx.AcousticEchoCanceler;
import android.os.Bundle;
import android.os.Environment;
import android.provider.CalendarContract.Instances;
import android.app.Activity;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.res.AssetManager;
import android.util.Log;
import android.view.Menu;
import android.widget.EditText;
import android.widget.TextView;


public class FeatureActivity extends Activity  {

	TextView min;
	TextView mean;
	TextView sdt ;
	TextView corr[] ;
	TextView ZeroCrossing;
	TextView deltaIndex;
	EditText[] CTM;
	EditText Baseline;
	EditText odi[];
	EditText[] ODIIS;
	EditText[][] ODI;
	EditText[] TSA;
	EditText mutin[];

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_feature);
		
		ODI = new EditText[6][4] ;
		corr = new EditText[6];
		TSA = new EditText[6] ;
		mutin = new EditText[5] ;
		odi = new EditText[3];
		ODIIS = new EditText[4];
		
		 min =  (TextView) findViewById(R.id.txtMin) ; 
		 mean =  (TextView) findViewById(R.id.txtMean) ; 
		 sdt =  (TextView) findViewById(R.id.txtSdt) ; 
		
		 corr[0] =  (TextView) findViewById(R.id.crrSpO21) ;
		 corr[1] =  (TextView) findViewById(R.id.crrSpO22) ;
		 corr[2] =  (TextView) findViewById(R.id.crrSpO23) ;
		 corr[3] =  (TextView) findViewById(R.id.crrSpO24) ;
		 corr[4] =  (TextView) findViewById(R.id.crrSpO25) ;
		 corr[5] =  (TextView) findViewById(R.id.crrSpO26) ;
		 
		 mutin[0] =  (EditText) findViewById(R.id.txtMutin1) ;
		 mutin[1] =  (EditText) findViewById(R.id.txtMutin2) ;
		 mutin[2] =  (EditText) findViewById(R.id.txtMutin3) ;
		 mutin[3] =  (EditText) findViewById(R.id.txtMutin4) ;
		 mutin[4] =  (EditText) findViewById(R.id.txtMutin5) ;
		 
		 ZeroCrossing =  (TextView) findViewById(R.id.txtZeroCrossing) ; 
		 deltaIndex =  (TextView) findViewById(R.id.txtdeltaIndex) ;
		 CTM = new EditText[4];
		 CTM[0] = (EditText) findViewById(R.id.txtCTM1) ;
		 CTM[1] = (EditText) findViewById(R.id.txtCTM2) ;
		 CTM[2] = (EditText) findViewById(R.id.txtCTM3) ;
		 CTM[3] = (EditText) findViewById(R.id.txtCTM4) ;
		 Baseline =  (EditText) findViewById(R.id.txtBaseline) ;
		 
		 odi[0] =  (EditText) findViewById(R.id.txtodi1) ;
		 odi[1] =  (EditText) findViewById(R.id.txtodi2) ;
		 odi[2] =  (EditText) findViewById(R.id.txtodi3) ;
		 
		 ODI[2][0] =  (EditText) findViewById(R.id.txtODI21) ;
		 ODI[2][1] =  (EditText) findViewById(R.id.txtODI23) ;
		 ODI[2][2] =  (EditText) findViewById(R.id.txtODI25) ;
		 
		 ODI[3][0] =  (EditText) findViewById(R.id.txtODI31) ;
		 ODI[3][1] =  (EditText) findViewById(R.id.txtODI33) ;
		 ODI[3][2] =  (EditText) findViewById(R.id.txtODI35) ;
		 
		 ODI[4][0] =  (EditText) findViewById(R.id.txtODI41) ;
		 ODI[4][1] =  (EditText) findViewById(R.id.txtODI43) ;
		 ODI[4][2] =  (EditText) findViewById(R.id.txtODI45) ;
		 
		 ODI[5][0] =  (EditText) findViewById(R.id.txtODI51) ;
		 ODI[5][1] =  (EditText) findViewById(R.id.txtODI53) ;
		 ODI[5][2] =  (EditText) findViewById(R.id.txtODI55) ;
		 
		 ODIIS[0] =  (EditText) findViewById(R.id.txtODIS1) ;
		 ODIIS[1] =  (EditText) findViewById(R.id.txtODIS2) ;
		 ODIIS[2] =  (EditText) findViewById(R.id.txtODIS3) ;
		 ODIIS[3] =  (EditText) findViewById(R.id.txtODIS4) ;
		 
		 TSA[0] = (EditText) findViewById(R.id.txtTSA70) ;
		 TSA[1] = (EditText) findViewById(R.id.txtTSA80) ;
		 TSA[2] = (EditText) findViewById(R.id.txtTSA80) ;
		 TSA[3] = (EditText) findViewById(R.id.txtTSA85) ;
		 TSA[4] = (EditText) findViewById(R.id.txtTSA90) ;
		 TSA[5] = (EditText) findViewById(R.id.txtTSA95) ;
		 
		double[]  spo2 = new double[60] ;
		spo2 =  getIntent().getDoubleArrayExtra("sps");
	}
	
/*	
	private String GetFeatures(double[] spo2) // input (6000)
	{

		min.setText( String.valueOf( Min(spo2) ));
		mean.setText( String.valueOf(Mean(spo2) ));
		
		double StdSpo2 =  StandardDeviation(spo2);
		sdt.setText(String.valueOf(StdSpo2));
	
		double[] corrmtx = corrmtx(spo2) ;
		for (int i = 0; i < corrmtx.length; i++) {
			corr[i].setText(String.valueOf(corrmtx[i]));
		}

		// mutin 
		
		double[][] Ex =  Extra(spo2);
		double[] first = new double[55];
		double[] second = new double[55];
		for (int k = 0; k < 5; k++) {
			for (int i = 0; i < 55 ; i++) {
				first[i] = Ex[i][k] ;
				second[i] = Ex[i][k+1] ;
			}
			mutin[k].setText(String.valueOf(mutin(first , second)));
		}
		
		
		ZeroCrossing.setText(String.valueOf( ZeroCrossing(spo2)));
		deltaIndex.setText(String.valueOf(daltaIndex(spo2)));
		double[] ress = CTM(spo2) ;
		for (int i = 0; i < 4; i++) {
			CTM[i].setText( String.valueOf(ress[i]));
		}
		Baseline.setText(String.valueOf( baseline(spo2) ));
		double [] od = ODI(spo2) ;
		for (int i = 0; i < odi.length; i++) {
			odi[i].setText(String.valueOf(od[i])) ;	
		}
		
		
		for (int i = 2; i < ODI.length; i++) {
			od = ODI(spo2 ,  i) ;
			for (int j = 0; j < od.length; j++) {
				ODI[i][j].setText(String.valueOf(od[j])) ;
			}
		}
		
		for (int i = 0; i < ODIIS.length; i++) {
			ODIIS[i].setText(String.valueOf(ODIS[i])) ;
		}
		
		
		for (int i =0 , j = 70 ; i < TSA.length; i++ , j+=5) {
				TSA[i].setText(String.valueOf(TSA(spo2 , j)) );
		}
		String Features =  MinSpO2 + MeanSpO2 +stdSpO2 + crrSpO2 +muinfSpO2 + zcSpO2 + DeltaindSpO2 
						+ CTMSpO2 + baselineSpO2 + odiSpO2 + ODISpO2 + tsaSpO2 + "-\n" ;
		return Features ;
	}
	*/


	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}


	

}
