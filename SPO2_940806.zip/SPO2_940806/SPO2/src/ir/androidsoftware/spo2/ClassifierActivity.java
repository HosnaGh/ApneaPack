package ir.androidsoftware.spo2;

import weka.classifiers.Classifier;
import weka.classifiers.meta.AdaBoostM1;
import weka.classifiers.meta.Bagging;
import weka.classifiers.trees.J48;
import weka.core.Instances;
import android.os.Bundle;
import android.app.Activity;
import android.content.DialogInterface;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

public class ClassifierActivity extends Activity implements OnClickListener {

	TextView txt_ada ; 
	TextView txt_TP ;
	TextView txt_TN ;
	TextView txt_FP ;
	TextView txt_FN ;
	
	TextView txt_bag ; 
	TextView txt_TP1 ;
	TextView txt_TN1 ;
	TextView txt_FP1 ;
	TextView txt_FN1 ;
	
	TextView txt_J48 ;
	TextView txt_TP2 ;
	TextView txt_TN2 ;
	TextView txt_FP2 ;
	TextView txt_FN2 ;
	
	Button run1 ;
	Button run2 ;
	Button run3 ;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_classifier);
		
		txt_ada = (TextView) findViewById(R.id.txt_Ada);
		txt_TP = (TextView) findViewById(R.id.txt_TP);  
		txt_TN = (TextView) findViewById(R.id.txt_TN);
		txt_FP = (TextView) findViewById(R.id.txt_FP);
		txt_FN = (TextView) findViewById(R.id.txt_FN);
		
		txt_bag = (TextView) findViewById(R.id.txt_bag);
		txt_TP1 = (TextView) findViewById(R.id.txt_TP1);  
		txt_TN1 = (TextView) findViewById(R.id.txt_TN1);
		txt_FP1 = (TextView) findViewById(R.id.txt_FP1);
		txt_FN1 = (TextView) findViewById(R.id.txt_FN1);
		
		txt_J48 = (TextView) findViewById(R.id.txt_J48);
		txt_TP2 = (TextView) findViewById(R.id.txt_TP2);  
		txt_TN2 = (TextView) findViewById(R.id.txt_TN2);
		txt_FP2 = (TextView) findViewById(R.id.txt_FP2);
		txt_FN2 = (TextView) findViewById(R.id.txt_FN2);
		
		run1 = (Button) findViewById(R.id.Run1) ;
		run2 = (Button) findViewById(R.id.Run2) ;
		run3 = (Button) findViewById(R.id.Run3) ;
		run1.setOnClickListener(this) ;
		run2.setOnClickListener(this) ;
		run3.setOnClickListener(this) ;
		
		Classifier("data0.arff") ;
	}
	private void Clear()
	{
		double[] ada = {0,0,0,0,0,0} ;
		txt_ada.setText(String.valueOf(ada[0]));
		txt_TP.setText(String.valueOf((int)ada[2]));
		txt_TN.setText(String.valueOf((int)ada[3]));
		txt_FP.setText(String.valueOf((int)ada[4]));
		txt_FN.setText(String.valueOf((int)ada[5]));
		
		double[] bag = {0,0,0,0,0,0} ;
		txt_bag.setText(String.valueOf(bag[0]));
		txt_TP1.setText(String.valueOf((int)bag[2]));
		txt_TN1.setText(String.valueOf((int)bag[3]));
		txt_FP1.setText(String.valueOf((int)bag[4]));
		txt_FN1.setText(String.valueOf((int)bag[5]));
		
		double[] j48 = {0,0,0,0,0,0} ;
		txt_J48.setText(String.valueOf(j48[0]));
		txt_TP2.setText(String.valueOf((int)j48[2]));
		txt_TN2.setText(String.valueOf((int)j48[3]));
		txt_FP2.setText(String.valueOf((int)j48[4]));
		txt_FN2.setText(String.valueOf((int)j48[5]));
	}
	private void Classifier(String filename ){
		Clear();
		 Classic cls = new Classic();
		 try {
			Instances ins = cls.loadInstancesFromARFF( filename);
			Classifier[] models = { 
					new AdaBoostM1(),
					new Bagging() ,
					new J48()};
			
			double[] ada = {0,0,0,0,0,0} ;
			ada = cls.Classify(ins, models[0] );
			txt_ada.setText(String.valueOf(ada[0]));
			txt_TP.setText(String.valueOf((int)ada[2]));
			txt_TN.setText(String.valueOf((int)ada[3]));
			txt_FP.setText(String.valueOf((int)ada[4]));
			txt_FN.setText(String.valueOf((int)ada[5]));
			
			double[] bag = {0,0,0,0,0,0} ;
			bag = cls.Classify(ins, models[1] );
			txt_bag.setText(String.valueOf(bag[0]));
			txt_TP1.setText(String.valueOf((int)bag[2]));
			txt_TN1.setText(String.valueOf((int)bag[3]));
			txt_FP1.setText(String.valueOf((int)bag[4]));
			txt_FN1.setText(String.valueOf((int)bag[5]));
			
			double[] j48 = {0,0,0,0,0,0} ;
			j48 = cls.Classify(ins, models[2] );
			txt_J48.setText(String.valueOf(j48[0]));
			txt_TP2.setText(String.valueOf((int)j48[2]));
			txt_TN2.setText(String.valueOf((int)j48[3]));
			txt_FP2.setText(String.valueOf((int)j48[4]));
			txt_FN2.setText(String.valueOf((int)j48[5]));

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.classifier, menu);
		return true;
	}



	@Override
	public void onClick(View V) {
		// TODO Auto-generated method stub
		switch (V.getId()){
		case R.id.Run1:
			Classifier("data0.arff") ;
			break;
		case R.id.Run2:
			Classifier("data1.arff") ;
			break;
		case R.id.Run3:
			Classifier("data2.arff") ;
			break;
		default:
			break;
		}
	}

}
