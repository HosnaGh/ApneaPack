package ir.androidsoftware.spo2;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import org.joda.time.DateTime;


import android.os.Environment;

public class Warehouse {
	DateTime dt;
	String name;
	Warehouse()
	{
		File myFile = new File(Environment.getExternalStorageDirectory()+"/ApneaPack/" + File.separator +"spo2.txt");
			if (myFile.exists()) {
				myFile.delete();
			}
		dt= DateTime.now();
		 name = String.valueOf(dt).replace(':', '-').replace('.', '-') ;
		WriteToFile("\n"+dt +"\n") ;
	}

	public  void WriteToFile(String data)
	{
		StringWriter sw = new StringWriter();
	    PrintWriter pw = new PrintWriter(sw);
	    //ex.printStackTrace(pw);
	    
	    data += sw.toString();
		try {
			File mydir = new File(Environment.getExternalStorageDirectory()+"/ApneaPack" );
			if(mydir.exists()==false)
			{
				mydir.mkdir();
			}
			File myFile = new File(Environment.getExternalStorageDirectory()+"/ApneaPack/" + File.separator +"spo2.txt");
			
			if(myFile.exists()==false)
			{
				try {
					myFile.createNewFile();
				} catch (IOException e1) {
					e1.printStackTrace();
				}
			}

			try {
				BufferedWriter buf = new BufferedWriter(new FileWriter(myFile,true));
				buf.append(data);
			    buf.newLine();
			    buf.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
					
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
