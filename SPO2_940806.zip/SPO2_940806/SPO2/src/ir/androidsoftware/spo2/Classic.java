package ir.androidsoftware.spo2;


import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import android.content.Context;
import android.os.Environment;
import weka.classifiers.Classifier;
import weka.classifiers.Evaluation;
import weka.classifiers.evaluation.NominalPrediction;
import weka.classifiers.meta.AdaBoostM1;
import weka.classifiers.rules.DecisionTable;
import weka.classifiers.rules.PART;
import weka.classifiers.trees.DecisionStump;
import weka.classifiers.trees.J48;
import weka.core.Attribute;
import weka.core.FastVector;
import weka.core.Instance;
import weka.core.Instances;
import weka.core.converters.ArffLoader;

public class Classic {	 

		public static BufferedReader readDataFile(String filename) {
			BufferedReader inputReader = null;
			try {
				inputReader = new BufferedReader(new FileReader(filename));
			} catch (FileNotFoundException ex) {
				System.err.println("File not found: " + filename);
			}
	 
			return inputReader;
		}
	 
		public static Evaluation classify(Classifier model,
				Instances trainingSet, Instances testingSet) throws Exception {
			Evaluation evaluation = new Evaluation(trainingSet);
	 
			model.buildClassifier(trainingSet);
			evaluation.evaluateModel(model, testingSet);
	 
			return evaluation;
		}
	 
		public static double[] calculateAccuracy(FastVector predictions) {
			double correct = 0;
	 			int TP = 0 ;
				int TN=0;
				int FP =0;
				int FN=0;
			for (int i = 0; i < predictions.size(); i++) {
				NominalPrediction np = (NominalPrediction) predictions.elementAt(i);
				// np.equals(NominalPrediction.MISSING_VALUE))
				if (np.predicted() == np.actual() ) {
					correct++;
				}
	
				if (np.predicted() == np.actual() && np.actual()==1 ) {
					TP++; 
				}
				else if (np.predicted() == np.actual() && np.actual()==0) {
					TN++;
				}
				else if (np.predicted() != np.actual() && np.actual()==1) {
					FP++;
				}
				else if (np.predicted() != np.actual() && np.actual()==0) {
					FN++;
				}
			}
			
			double accur =100* (TN+TP) / predictions.size() ;
			//double sensitivity = TP/(TP+FN) ;
			//double specificity = TN/(TN+FP) ;
			
				double[] T = new double[6];
			
				T[0] =	100 * correct / predictions.size();
			T[1] = accur ;
			T[2] = TP ;
			T[3] = TN ;
			T[4] = FP ;
			T[5] = FN ;
			return T;
		}
	 
		public static Instances[][] crossValidationSplit(Instances data, int numberOfFolds) {
			Instances[][] split = new Instances[2][numberOfFolds];
	 
			for (int i = 0; i < numberOfFolds; i++) {
				split[0][i] = data.trainCV(numberOfFolds, i);
				split[1][i] = data.testCV(numberOfFolds, i);
			}
	 
			return split;
		}
	 
		public  double[] Classify(Instances data , Classifier model) throws Exception{
			
			data.setClassIndex(data.numAttributes() - 1);
	 
			// Do 10-split cross validation
			Instances[][] split = crossValidationSplit(data, 10);
	 
			// Separate split into training and testing arrays
			Instances[] trainingSplits = split[0];
			Instances[] testingSplits = split[1];
	 

	 
			// Run for each model
			//for (int j = 0; j < models.length; j++) {
	 
				// Collect every group of predictions for current model in a FastVector
				FastVector predictions = new FastVector();
	 
				// For each training-testing split pair, train and test the classifier
				for (int i = 0; i < trainingSplits.length; i++) {
					Evaluation validation = classify(model, trainingSplits[i], testingSplits[i]);
	 
					predictions.appendElements(validation.predictions());
	 
				}
	 
				// Calculate overall accuracy of current classifier on all splits
				double[] accuracy = calculateAccuracy(predictions);
	
				
				return accuracy ;
			}
	 
		//}
		
		public Instances loadInstancesFromARFF(String filename) throws IOException {
			File file = new File(Environment.getExternalStorageDirectory()+"/ApneaPack/" + File.separator +filename);
			 // File file=new File(TEST_RESOURCES,filename);
			  // assertTrue(file.exists());
			  ArffLoader loader=new ArffLoader();
			  loader.setFile(file);
			  Instances insts=loader.getDataSet();
			  //Attribute classAttribute=insts.attribute(className);
			  //insts.setClass(classAttribute);
			  return insts;
			}
		
		/*
		public void Convertor()
		{
			 FastVector atts = new FastVector<Attribute>(2);
		        ArrayList<String> classVal = new ArrayList<String>();
		        classVal.add("A");
		        classVal.add("B");
		        atts.add(new Attribute("content"));
		        atts.add(new Attribute("@@class@@"));

		        Instances dataRaw = new Instances("TestInstances",atts,0);
		        System.out.println("Before adding any instance");
		        System.out.println("--------------------------");
		        System.out.println(dataRaw);
		        System.out.println("--------------------------");

		        double[] instanceValue1 = new double[dataRaw.numAttributes()];

		        instanceValue1[0] = dataRaw.attribute(0).addStringValue("This is a string!");
		        instanceValue1[1] = 0;

		        dataRaw.add(new Instance(1.0, instanceValue1));

		        System.out.println("After adding a instance");
		        System.out.println("--------------------------");
		        System.out.println(dataRaw);
		        System.out.println("--------------------------");

		        double[] instanceValue2 = new double[dataRaw.numAttributes()];

		        instanceValue2[0] = dataRaw.attribute(0).addStringValue("This is second string!");
		        instanceValue2[1] = 1;

		        dataRaw.add(new Instance(1.0, instanceValue2));

		        System.out.println("After adding second instance");
		        System.out.println("--------------------------");
		        System.out.println(dataRaw);
		        System.out.println("--------------------------");
		}*/
	}
	

