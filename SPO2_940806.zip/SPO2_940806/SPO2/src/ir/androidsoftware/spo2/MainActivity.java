package ir.androidsoftware.spo2;

import java.io.IOException;
import java.sql.Date;

import weka.classifiers.meta.AdaBoostM1;
import weka.core.Instances;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.Legend.LegendForm;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.components.YAxis.AxisDependency;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.utils.ColorTemplate;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

	TextView tvSpO2;
	TextView tvAhi;
	TextView tvPulse;
	Button btnStartStop;
	BluetoothReader btReader;
	private LineChart mChart;
	Feature  feacher;
	Warehouse ware ; 
	int Ahi=0;
	int id = 0 ;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		startActivity(new Intent(MainActivity.this , ClassifierActivity.class));
		
		//ware = new Warehouse();
		//feacher = new Feature("data"+id+".arff") ;
		
		btReader = new BluetoothReader();
		mChart = (LineChart) findViewById(R.id.chart);
		tvSpO2 = (TextView)findViewById(R.id.tvSpO2);
		tvAhi = (TextView)findViewById(R.id.tvAhi);
		tvPulse = (TextView)findViewById(R.id.tvPulse);
		btnStartStop = (Button)findViewById(R.id.btnStartStop);
		btnStartStop.setOnClickListener(btnStartStopClicked);
		initChart();
	}
		
	OnClickListener btnStartStopClicked = new OnClickListener() {		
		@Override
		public void onClick(View v) {
			try {
				if(btReader.isStarted())
				{					
					btnStartStop.setText("Start");
					btReader.stopBt();
					btReader.disconnect();
					startActivity(new Intent(MainActivity.this, ClassifierActivity.class ));
				}else
				{
					mChart.getData().clearValues();
					btnStartStop.setText("Stop");
					btReader.connect();
					btReader.startBtOp(MainActivity.this);
				}
			} catch (IOException e) {
				Toast.makeText(MainActivity.this, "خطا در ارتباط با دستگاه", Toast.LENGTH_LONG).show();
				e.printStackTrace();
			}
			
		}
	};

	double[] sps = new double[60];
	int second = 0 ;
	int minute=0;
	public void displayVals(final byte spO2,final byte pulse)
	{
		runOnUiThread(new Runnable() {
			
			@Override
			public void run() {
				tvPulse.setText(String.valueOf(pulse));
				tvSpO2.setText("spO2:"+String.valueOf(spO2));
				sps[second] =(double) spO2;
				second ++ ;
				addEntry(spO2);
				if (minute > 12) {
					minute = 0 ; 
					id ++ ;
					ware = new Warehouse();
					feacher = new Feature("data"+id+".arff") ;
					
					Classic cls = new Classic();
					double[] text = new double[6] ;
					try {
						Instances ins = cls.loadInstancesFromARFF("data"+id+".arff");
						text = cls.Classify(ins, new AdaBoostM1() );
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					tvAhi.setText("AHI:"+ String.valueOf((int)(0.3*text[3])));
					
				}
				if (second>59) {
					second = 0;
					minute ++ ;
					//btReader.stopBt();
					//btReader.disconnect();
					//Intent intent = new Intent(MainActivity.this , FeatureActivity.class);
					//intent.putExtra("sps", sps);
					//startActivity(intent);
					
					feacher.GetFeatures(sps);
					String sp = null; 
					for (double palse : sps) {
						sp = sp + String.valueOf(palse)+","; 
					}
					ware.WriteToFile(sp);
				}
			}
		});
	}
	
	void initChart()
	{
		// enable touch gestures
        mChart.setTouchEnabled(true);

        // enable scaling and dragging
        mChart.setDragEnabled(true);
        mChart.setScaleEnabled(true);
        mChart.setDrawGridBackground(false);

        // if disabled, scaling can be done on x- and y-axis separately
        mChart.setPinchZoom(true);

        // set an alternative background color
        mChart.setBackgroundColor(Color.LTGRAY);

        LineData data = new LineData();
        data.setValueTextColor(Color.WHITE);

        // add empty data
        mChart.setData(data);
        // get the legend (only possible after setting data)
        com.github.mikephil.charting.components.Legend l = mChart.getLegend();

        // modify the legend ...
        // l.setPosition(LegendPosition.LEFT_OF_CHART);
        l.setForm(LegendForm.LINE);
        l.setTextColor(Color.WHITE);
        XAxis xl = mChart.getXAxis();       
        xl.setTextColor(Color.WHITE);
        xl.setDrawGridLines(false);
        xl.setAvoidFirstLastClipping(true);
        xl.setSpaceBetweenLabels(3);
        xl.setEnabled(true);

        YAxis leftAxis = mChart.getAxisLeft();
        leftAxis.setTextColor(Color.WHITE);
        leftAxis.setAxisMaxValue(100f);
        leftAxis.setAxisMinValue(70f);
        leftAxis.setStartAtZero(false);
        leftAxis.setDrawGridLines(true);

        YAxis rightAxis = mChart.getAxisRight();
        rightAxis.setEnabled(false);
	}
	

    private void addEntry(int yVal) {

        LineData data = mChart.getData();

        if (data != null) {

            LineDataSet set = data.getDataSetByIndex(0);
            // set.addEntry(...); // can be called as well

            if (set == null) {
                set = createSet();
                data.addDataSet(set);
            }

            // add a new x-value first
            data.addXValue("x");
            data.addEntry(new Entry((float) yVal, set.getEntryCount()), 0);


            // let the chart know it's data has changed
            mChart.notifyDataSetChanged();

            // limit the number of visible entries
            mChart.setVisibleXRangeMaximum(60);
            // mChart.setVisibleYRange(30, AxisDependency.LEFT);

            // move to the latest entry
            mChart.moveViewToX(data.getXValCount() - 61);

            // this automatically refreshes the chart (calls invalidate())
            // mChart.moveViewTo(data.getXValCount()-7, 55f,
            // AxisDependency.LEFT);
        }
    }

    private LineDataSet createSet() {

        LineDataSet set = new LineDataSet(null, "Dynamic Data");
        set.setAxisDependency(AxisDependency.LEFT);
        set.setColor(ColorTemplate.getHoloBlue());
        set.setCircleColor(Color.WHITE);
        set.setLineWidth(2f);
        set.setCircleSize(4f);
        set.setFillAlpha(65);
        set.setFillColor(ColorTemplate.getHoloBlue());
        set.setHighLightColor(Color.rgb(244, 117, 117));
        set.setValueTextColor(Color.WHITE);
        set.setValueTextSize(9f);
        set.setDrawValues(false);
        return set;
    }   
}
